#' Transform a..
#'
#' @param Y is a data frame or a matrix
#'
#' @return The dummy matrix
#' @export
#'
#' @examples
#' dummy(iris[,5])

#Transform a categorial target variable in a dummy matrix
dummy<-function(Y){
  if (is.factor(Y)==FALSE){
    stop("The variable must be a factor")
  }else{
  Y_dummy<-as.matrix(sapply(levels(Y),function(x){ifelse(Y==x,1,0)}))
  return(Y_dummy)
  }
}
