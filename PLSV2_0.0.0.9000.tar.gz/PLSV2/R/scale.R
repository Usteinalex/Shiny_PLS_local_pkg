#' Scale
#'
#' @param X a matrix or data frame
#' @param reduce if True reduced, if False centered
#'
#' @importFrom stats sd
#'
#' @return The explicatives variables columns.
#' @export
#'
#' @examples
#' xscale(iris[,1:4])
#' xscale(iris[,1:4],reduce=FALSE)

#scale a matrix
xscale<-function(X,reduce=TRUE){
  #Transform X in a matrix class
  X<-as.matrix(X)
  if(typeof(X)!="double"){
    stop("Not expected character's matrix")
  }
  #compute the coefficients of the matrix in substracting the mean
  #corresponding to the column where the coefficient is situated
  X_scale<-apply(X,2,function(x){return(x-mean(x))})
  #reduce the coefficients of the matrix if reduce is TRUE
  if(reduce==TRUE){
    #check if some columns have a standard deviation equal to 0
    stdev<-apply(X,2,sd)
    for (i in 1:ncol(X)){
      if (stdev[i]==0){
        print("Becarful : a minimum of one column as a standard deviation of 0")
      }else{
        #compute the coefficients of the matrix in dividing the standard
        #corresponding to the column where the coefficient is situated
        X_scale <- apply(X_scale,2,function(x){return(x/sd(x))})
      }
    }
  }
  return(X_scale)
}
